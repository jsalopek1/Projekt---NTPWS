<?php
session_start();
include("menu.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);
    
    $conn = new mysqli("localhost", "root", "", "projektphp");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $sql = "INSERT INTO questions (user_id, question) VALUES (NULL, '$message')";
    if ($conn->query($sql) === TRUE) {
        echo "<p>Thank you for your message, $name!</p>";
    } else {
        echo "<p>Error: " . $conn->error . "</p>";
    }
    
    $conn->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Contact - Tennis Highlights</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Contact Us</h1>
    </header>
    <main>
        <form method="post" action="">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="message">Message:</label>
            <textarea id="message" name="message" required></textarea>
            
            <button type="submit">Send</button>
        </form>
    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Tennis Highlights | Created by Josip Salopek</p>
    </footer>
</body>
</html>

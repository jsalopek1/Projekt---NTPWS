<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: signin.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "projektphp");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT users.id, users.name, users.email, country.name AS country FROM users 
        LEFT JOIN country ON users.country_id = country.id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel - Tennis Highlights</title>
    <link rel="stylesheet" href="..style.css">
</head>
<body>
    <header>
        <h1>Admin Panel</h1>
    </header>
    <main>
        <h2>All Users</h2>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Country</th>
            </tr>
            <?php
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['email']}</td>
                        <td>{$row['country']}</td>
                      </tr>";
            }
            ?>
        </table>
    </main>
</body>
</html>

<?php
$conn->close();
?>

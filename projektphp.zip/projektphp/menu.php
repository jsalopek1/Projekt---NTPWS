<?php
echo '<nav>
    <ul>
        <li><a href="index.php">Home</a></li>';

if (isset($_SESSION['user_id'])) { 
    echo '<li><a href="highlights.php">Highlights</a></li>';
    echo '<li><a href="users.php">Users</a></li>';
    echo '<li><a href="contact.php">Contact</a></li>';
    echo '<li><a href="logout.php">Logout</a></li>';
} else {
    echo '<li><a href="about-us.php">About Us</a></li>';
    echo '<li><a href="contact.php">Contact</a></li>';
    echo '<li><a href="signin.php">Sign In</a></li>';
    echo '<li><a href="register.php">Register</a></li>';
}

echo '</ul>
</nav>';
?>

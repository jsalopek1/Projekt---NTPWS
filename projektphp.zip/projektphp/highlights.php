<?php
session_start();
include("menu.php");

$is_logged_in = isset($_SESSION['user_id']); 
$videos = [];
$error_message = "";

if ($is_logged_in) {
    $api_url = "https://www.googleapis.com/youtube/v3/search";
    $api_key = "AIzaSyCfFrYnqi38Yfqy8v2MLrgZrxgi7XxEKIY"; 
    $query = "tennis highlights"; 
    $max_results = 5;

    $url = "$api_url?part=snippet&q=" . urlencode($query) . "&type=video&maxResults=$max_results&key=$api_key";
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
    ]);

    $response = curl_exec($curl);
    $http_status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

    if ($http_status == 200) {
        $data = json_decode($response, true);
        $videos = $data['items']; 
    } else {
        $error_message = "Failed to fetch YouTube videos. HTTP Status Code: $http_status";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tennis Highlights</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Tennis Highlights</h1>
    </header>
    <main>
        <?php if ($is_logged_in): ?>
        <section class="youtube-highlights">
            <h2>Latest Tennis Highlights</h2>
            <?php if (!empty($videos)): ?>
            <ul>
                <?php foreach ($videos as $video): ?>
                <li>
                    <h3><?php echo htmlspecialchars($video['snippet']['title']); ?></h3>
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo $video['id']['videoId']; ?>" 
                        title="<?php echo htmlspecialchars($video['snippet']['title']); ?>" 
                        frameborder="0" allowfullscreen>
                    </iframe>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php else: ?>
            <p>No highlights available at the moment.</p>
            <?php endif; ?>
        </section>
        <?php else: ?>
        <p>You need to be logged in to view tennis highlights.</p>
        <?php endif; ?>
    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Tennis Highlights | Created by Josip Salopek</p>
    </footer>
</body>
</html>

<?php
session_start();
include("menu.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tennis Highlights</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/x-icon" href="favicon.jpeg">

</head>
<body>
    <header>
        <h1>Welcome to Tennis Highlights</h1>
        <p>Discover the best moments in tennis history!</p>
    </header>
    <main>
    <section class="player-highlight">
    <div class="section-content">
    <img src="img/djokovic.png" alt="Novak Djokovic" class="player-img">
    <div class="section-text">
            <h2>Novak Djokovic</h2>
            <p>
                Novak Djokovic is one of the greatest tennis players of all time. Known for his incredible athleticism 
                and mental toughness, Djokovic has won numerous Grand Slam titles, solidifying his legacy in tennis history.
            </p>
        </div>
    </div>
</section>

<section class="player-highlight">
    <div class="section-content reverse">
        <div class="section-text">
            <h2>Rafael Nadal</h2>
            <p>
                Rafael Nadal, also known as the King of Clay, has mesmerized tennis fans with his powerful forehand and 
                unmatched determination. With numerous Roland Garros titles, Nadal remains a symbol of hard work and excellence.
            </p>
        </div>
        <img src="img/nadal.jpg" alt="Rafael Nadal" class="player-img">
    </div>
</section>

    </main>
    <footer>
    <p>&copy; <?php echo date("Y"); ?> Tennis Highlights | Created by Josip Salopek</p>
    </footer>
</body>
</html>

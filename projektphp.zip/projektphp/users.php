<?php
session_start();
include("menu.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "projektphp");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id'];
    $delete_query = "DELETE FROM users WHERE id = $delete_id";

    if ($conn->query($delete_query) === TRUE) {
        header("Location: users.php");
        exit();
    } else {
        echo "<p>Error deleting user: " . $conn->error . "</p>";
    }
}

$result = $conn->query("SELECT id, name, username, email FROM users");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Korisnici - Tennis Highlights</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>List of Users</h1>
    </header>
    <main>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td>
                        <a href="edit-user.php?id=<?php echo $row['id']; ?>">Edit</a> |
                        <a href="users.php?delete_id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Tennis Highlights | Created by Josip Salopek</p>
    </footer>
</body>
</html>
<?php $conn->close(); ?>

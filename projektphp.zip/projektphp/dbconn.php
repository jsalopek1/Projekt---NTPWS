<?php
include("dbconn.php");

$conn->close(); 
?>

<?php
session_start();
include("menu.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Tennis Highlights</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/x-icon" href="favicon.jpeg">
</head>
<body>
    <header>
        <h1>About Us</h1>
    </header>
    <main>
        <section class="about-us">
            <h2>Welcome to  Tennis Highlights</h2>
            <p>
                Tennis Highlights is your go-to platform for reliving the most exciting moments in tennis history. 
                From legendary matches to unforgettable rallies, we bring you the best highlights from the world of tennis.
            </p>
            <p>
                Explore iconic matches, learn about the players, and dive deep into the passion of tennis.
            </p>
        </section>
        
        <section class="about-author">
            <img src="img/author.jpeg" alt="Josip Salopek" class="author-img">
            <p>
                This project was created by Josip Salopek, a tennis enthusiast. 
                Combining his love for technology and sports, Josip designed this platform to connect tennis fans worldwide.
            </p>
            <p>
                Feel free to reach out with feedback or suggestions – let's make Tennis Highlights even better together!
            </p>
        </section>
    </main>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Tennis Highlights | Created by Josip Salopek</p>
    </footer>
</body>
</html>

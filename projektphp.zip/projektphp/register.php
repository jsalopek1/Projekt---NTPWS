<?php
session_start();
include("menu.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = new mysqli("localhost", "root", "", "projektphp");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $country_code = mysqli_real_escape_string($conn, $_POST['country']);

    $check_query = "SELECT * FROM users WHERE email = '$email' OR username = '$username'";
    $check_result = $conn->query($check_query);

    if ($check_result->num_rows > 0) {
        echo "<div class='container alert alert-danger mt-3'>Email or Username already exists. Please try again.</div>";
    } else {
        $insert_query = "INSERT INTO users (name, username, email, password, country_id, role) 
                         VALUES ('$first_name $last_name', '$username', '$email', '$password', '$country_code', 'user')";

        if ($conn->query($insert_query)) {
            echo "<div class='container alert alert-success mt-3'>Registration successful! Welcome, $first_name.</div>";
        } else {
            echo "<div class='container alert alert-danger mt-3'>Error: " . $conn->error . "</div>";
        }
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Tennis Highlights</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container registration-form">
        <h2 class="text-center mb-4">User Registration</h2>
        <form method="POST">
            <div class="mb-3">
                <label for="first_name" class="form-label">First Name:*</label>
                <input type="text" class="form-control" id="first_name" name="first_name" required>
            </div>
            <div class="mb-3">
                <label for="last_name" class="form-label">Last Name:*</label>
                <input type="text" class="form-control" id="last_name" name="last_name" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Your E-mail:*</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="username" class="form-label">
                    Username:* <span class="help-text">(Username must have min 5 and max 10 characters)</span>
                </label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">
                    Password:* <span class="help-text">(Password must have min 4 characters)</span>
                </label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <div class="mb-3">
                <label for="country" class="form-label">Country</label>
                <select class="form-select" id="country" name="country" required>
                    <option value="">Select Country</option>
                    <?php
                    $conn = new mysqli("localhost", "root", "", "projektphp");
                    $country_query = "SELECT id, name FROM country";
                    $country_result = $conn->query($country_query);

                    while ($country = $country_result->fetch_assoc()) {
                        echo "<option value='" . $country['id'] . "'>" . $country['name'] . "</option>";
                    }

                    $conn->close();
                    ?>
                </select>
            </div>
            <button type="submit" class="btn-primary">Submit</button>
        </form>
    </div>
    <footer>
        <p>&copy; <?php echo date("Y"); ?> Tennis Highlights | Created by Josip Salopek</p>
    </footer>
</body>
</html>
